/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package podmiana_elt_w_scenie;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author amelk
 */
public class pierwszyController implements Initializable {
    @FXML 
    AnchorPane rootPane;
    @FXML
    Label tytul;
    @FXML ImageView obrazek_lekka;//
    @FXML ImageView plywanie;
    @FXML ImageView sporty_zimowe;
    @FXML
    ChoiceBox box_lekka;
    @FXML
    ChoiceBox box_plyw;
    @FXML
    ChoiceBox box_zim;
    @FXML
    Button podmianka_b;
    
    ObservableList<String> Lekkoatletyka_Sportsmenki = FXCollections.observableArrayList("Ewa Swoboda", "Anita Włodarczyk");
    ObservableList<String> Plywanie_Sportsmenki = FXCollections.observableArrayList("Otylia Jędrzejczak", "Alicja Tchórz");
    ObservableList<String> Zimowe_Sportsmenki = FXCollections.observableArrayList("Justyna Kowalczyk", "Anna Jurkiewicz");
    
     Image Swoboda = new Image("podmiana_elt_w_scenie/swoboda.png");
     Image Wlodarczyk = new Image("podmiana_elt_w_scenie/wlodarczyk.png");
     final Image[] lekkoatletki = new Image[]{Swoboda,Wlodarczyk};
     
     Image Jedrzejczak = new Image("podmiana_elt_w_scenie/jedrzejczak.png");
     Image Tchorz = new Image("podmiana_elt_w_scenie/tchorz.png");
     final Image[] plywaczki = new Image[]{Jedrzejczak, Tchorz};
     
     Image Kowalczyk = new Image("podmiana_elt_w_scenie/kowalczyk.png");
     Image Jurkiewicz = new Image("podmiana_elt_w_scenie/jurkiewicz.png");
     final Image[] zimowe_atl = new Image[]{Kowalczyk,Jurkiewicz};
     
     
   @FXML public void podmianka(ActionEvent event) throws IOException {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("drugi.fxml"));
        rootPane.getChildren().setAll(pane);
	}

    @FXML 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        box_lekka.setItems(Lekkoatletyka_Sportsmenki);
        box_plyw.setItems(Plywanie_Sportsmenki);
        box_zim.setItems(Zimowe_Sportsmenki);
        clik_lekkoatletyka();
        clik_plywanie();
        clik_zimowe();
    }
    
    @FXML
    public void clik_lekkoatletyka() {
        box_lekka.getSelectionModel().selectedIndexProperty().addListener((v, oldValue, newValue) -> {
            obrazek_lekka.setImage(lekkoatletki[newValue.intValue()]);
        });
     }
    
    @FXML
    public void clik_plywanie() {
        box_plyw.getSelectionModel().selectedIndexProperty().addListener((v, oldValue, newValue) -> {
            plywanie.setImage(plywaczki[newValue.intValue()]);
        });
     }
    
    @FXML
    public void clik_zimowe() {
        box_zim.getSelectionModel().selectedIndexProperty().addListener((v, oldValue, newValue) -> {
            sporty_zimowe.setImage(zimowe_atl[newValue.intValue()]);
        });
     }
    
}