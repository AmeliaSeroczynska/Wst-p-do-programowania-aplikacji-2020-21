/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package podmiana_elt_w_scenie;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author amelk
 */
public class drugiController implements Initializable {
    @FXML
    AnchorPane rootPane2;
    @FXML
    Label tytul;
    @FXML ImageView obrazek_lekka;//
    @FXML ImageView plywanie;
    @FXML ImageView sporty_zimowe;
    @FXML
    ChoiceBox box_lekka;
    @FXML
    ChoiceBox box_plyw;
    @FXML
    ChoiceBox box_zim;
    @FXML
    Button podmianka_b;
    
    ObservableList<String> Lekkoatletyka_Sportsmeni = FXCollections.observableArrayList("Tomasz Majewski", "Adam Kszczot");
    ObservableList<String> Plywanie_Sportsmeni = FXCollections.observableArrayList("Paweł Korzeniowski", "Radosław Kawęcki");
    ObservableList<String> Zimowe_Sportsmeni = FXCollections.observableArrayList("Kamil Stoch", "Artur Nogal");
    
     Image Majewski = new Image("podmiana_elt_w_scenie/majewski.png");
     Image Kszczot = new Image("podmiana_elt_w_scenie/kszczot.png");
     final Image[] lekkoatleci = new Image[]{Majewski,Kszczot};
     
     Image Korzeniowski = new Image("podmiana_elt_w_scenie/korzeniowski.png");
     Image Kawecki = new Image("podmiana_elt_w_scenie/kawecki.png");
     final Image[] plywacy = new Image[]{Korzeniowski,Kawecki};
     
     Image Stoch = new Image("podmiana_elt_w_scenie/stoch.png");
     Image Nogal = new Image("podmiana_elt_w_scenie/nogal.png");
     final Image[] zimowe_atl = new Image[]{Stoch,Nogal};
     
    @FXML public void podmianka(ActionEvent event) throws IOException {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("pierwszy.fxml"));
        rootPane2.getChildren().setAll(pane);
	}

    @FXML 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        box_lekka.setItems(Lekkoatletyka_Sportsmeni);
        box_plyw.setItems(Plywanie_Sportsmeni);
        box_zim.setItems(Zimowe_Sportsmeni);
        clik_lekkoatletyka();
        clik_plywanie();
        clik_zimowe();
    }
    
    @FXML
    public void clik_lekkoatletyka() {
        box_lekka.getSelectionModel().selectedIndexProperty().addListener((v, oldValue, newValue) -> {
            obrazek_lekka.setImage(lekkoatleci[newValue.intValue()]);
        });
     }
    
    @FXML
    public void clik_plywanie() {
        box_plyw.getSelectionModel().selectedIndexProperty().addListener((v, oldValue, newValue) -> {
            plywanie.setImage(plywacy[newValue.intValue()]);
        });
     }
    
    @FXML
    public void clik_zimowe() {
        box_zim.getSelectionModel().selectedIndexProperty().addListener((v, oldValue, newValue) -> {
            sporty_zimowe.setImage(zimowe_atl[newValue.intValue()]);
        });
     }
    
}
